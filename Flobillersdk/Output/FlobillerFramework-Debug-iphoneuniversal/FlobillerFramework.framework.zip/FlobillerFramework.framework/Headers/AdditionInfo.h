//
//  AdditionInfo.h
//  Flobillersdk
//
//  Created by Do Quoc Lam on 11/1/16.
//  Copyright © 2016 Do Quoc Lam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdditionInfo : NSObject
@property (strong, nonatomic) NSMutableArray *fields;
@end
