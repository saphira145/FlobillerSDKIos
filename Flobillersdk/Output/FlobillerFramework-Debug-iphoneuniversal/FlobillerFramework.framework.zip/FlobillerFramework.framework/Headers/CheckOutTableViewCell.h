//
//  CheckOutTableViewCell.h
//  Flobillersdk
//
//  Created by Do Quoc Lam on 11/7/16.
//  Copyright © 2016 Do Quoc Lam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckOutTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end
