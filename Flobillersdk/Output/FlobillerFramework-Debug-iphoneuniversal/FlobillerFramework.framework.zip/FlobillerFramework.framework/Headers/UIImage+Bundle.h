//
//  UIImage+Bundle.h
//  Flobillersdk
//
//  Created by Do Quoc Lam on 11/18/16.
//  Copyright © 2016 Do Quoc Lam. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIImage (Bundle)
+(UIImage *)imageNamedInBundle:(NSString *)name;
@end
